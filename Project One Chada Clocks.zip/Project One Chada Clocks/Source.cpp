/*
Author	: @Suraj Hamal
Course	: CS-210-Programming
Company	: CHADA TECH
purpose : 12 and 24 hour clock display with current time where user can able to
		  add hours, minutes and seconds.
*/

#define _CRT_SECURE_NO_WARNINGS
// using standard library needed for the program
#include <iostream>		
#include <ctime>		
#include <string>
#include <iomanip>
#include <time.h>		

using namespace std;


// variable declaration needed for the program used in different functions below
int hoursStandard;	// 12 hours format
int hoursMilitary;  // 24 hours format
int minutes;		// minutes
int seconds;        // seconds
string ampm;		// AM or PM

// **********Defining Functions needed for the program***************************************
//-------------------------------------------------------------------------------------------

// Function to add hours to the clock
void AddHour() {
	hoursStandard += 1;		// Increments hours

	// using if condition to check and convert Standard and Military time and AM to PM
	if (hoursStandard >= 12) {
		hoursStandard = hoursStandard - 12;
		if (ampm == "AM") {
			ampm = "PM";
		}
		else {
			ampm = "AM";
		}
	}

}
//-------------------------------------------------------------------------------------------

// Function to add minutes to the clock
void AddMinute() {
	minutes += 1; // Increments minutes

	// using if condition to check and reset minute if the minutes goes over 60
	if (minutes >= 60) {
		minutes = 0; // if true, Reseting minutes to zero
		AddHour();
	}
}
//-------------------------------------------------------------------------------------------

// Function to add seconds to the clock
void AddSecond() {
	seconds += 1; // Increments seconds

	// using if condition to check minute and reset if the seconds goes over 60
	if (seconds >= 60) {
		seconds = 0; // if true, Resets seconds to zero
		AddMinute();
	}
}
//-------------------------------------------------------------------------------------------

// Function to display the edit clock menu to the user
void UserMenu() {

	// Prints the options menu for the user
	cout << "                         MENU                       " << endl;
	cout << "              **************************            " << endl;
	cout << "              * 1 - Add One Hour       *            " << endl;
	cout << "              * 2 - Add One Minute     *            " << endl;
	cout << "              * 3 - Add One Second     *            " << endl;
	cout << "              * 4 - Exit Program       *            " << endl;
	cout << "              **************************            " << endl;
	cout << endl;
}
//-------------------------------------------------------------------------------------------

// Function to display both clocks
void DisplayClocks() {

	// using if statement to check if the hoursMilitary is greater than or equal to 12 to show the converted time on the 12 hour clock
	if (hoursMilitary >= 12) {
		hoursStandard = hoursMilitary - 12;
		ampm = "PM";
	}
	else {
		ampm = "AM";
	}

	// MENU - TOP LINE
	cout << setfill('*') << setw(23) << "" << "\t\t";
	cout << setfill('*') << setw(23) << "" << endl;

	// MENU - 12 hour and 24 hour clock
	cout << "*    12-Hour Clock    *" << "\t\t" << "*    24-Hour Clock    *" << endl;

	// MENU - Time Line of 12 hour clock
	printf("*     %02d:%02d:%02d", hoursStandard, minutes, seconds);
	cout << " " << ampm << "     *";

	// MENU - Time Line of 24 hours clock
	printf("\t\t*      %02d:%02d:%02d       *", hoursMilitary, minutes, seconds);
	cout << endl;

	// MENU - BOTTOM LINE
	cout << setfill('*') << setw(23) << "" << "\t\t";
	cout << setfill('*') << setw(23) << "" << endl;
}
//------------------------------------------------------------------------------------------

// Function to convert or set the range for 24 hour clock  
void ClockConversion() {
	// using if condition to convert and set the range of 24 hour clock  
	if (ampm == "AM") {
		hoursMilitary = hoursStandard;
		if (hoursMilitary >= 24) {
			hoursMilitary = hoursMilitary - 24;
		}
	}
	else {
		hoursMilitary = hoursStandard + 12;
	}
}
//--------------------------------END OF THE FUNCTIONS--------------------------------------

//--------------------------------MAIN FUNCTION---------------------------------------------

int main() {

	/* Using the c++ build in function to call the current time and assigning
	   hour, minute and seconds of the time to its variables */
	time_t total_seconds = time(0);
	struct tm* ct = localtime(&total_seconds);
	seconds = ct->tm_sec;
	minutes = ct->tm_min;
	hoursStandard = ct->tm_hour;

	// Using if condition to recheck the current time every time programs runs if its more than 12 to set the 12 hour clock
	if (hoursMilitary >= 12) {
		hoursStandard = hoursMilitary - 12;
		ampm = "PM";
	}
	else {
		ampm = "AM";
	}
	// initailizing the variable for the user choice input, loop and menu selection
	int userChoice = 0;

	while (userChoice != 4) {	// using while loop to loop until user exits the program

		// Calling the ClockConversion to check the am or pm, DisplayClock to display the clocks with current time
		// and UserMenu to show the options to the user at the start of the program 
		ClockConversion();
		DisplayClocks();
		UserMenu();

		// getting the input from the user and storing it to the variable
		cout << "Enter your Choice: " << endl;
		cin >> userChoice;

		// Using switch statement for the menu options for the user
		switch (userChoice) {

		case 1:			// calls AddHour function and adds one hour to the both clocks everytime user chooses this option
			AddHour();
			cout << "You have choosed option 1. One hour is added to the clock!!!" << endl;
			cout << "Now, Choose another option!!!" << endl;
			cout << setfill('-') << setw(80) << "" << endl;
			break;
		case 2:			// calls AddMinute function and adds one minute to the both clocks everytime user chooses this option
			AddMinute();
			cout << "You have choosed option 2. One minute is added to the clock!!!" << endl;
			cout << "Now, Choose another option!!!" << endl;
			cout << setfill('-') << setw(80) << "" << endl;
			break;
		case 3:			// calls AddSecond function and adds one second to both clocks everytime user chooses this option
			AddSecond();
			cout << "You have choosed option 3. One second is added to the clock!!!" << endl;
			cout << "Now, Choose another option!!!" << endl;
			cout << setfill('-') << setw(80) << "" << endl;
			break;
		case 4:			// breaks out of the loop and end the program
			cout << "You have choosed option 4 to quit the Program. Thank You and GoodBye....." << endl;
			cout << setfill('-') << setw(80) << "" << endl;
			break;
		default:		// warns the user if invalid option is typed by the user
			cout << "Invalid option. Select the correct option from the Menu." << endl;
			cout << setfill('-') << setw(80) << "" << endl;
			break;
		}
	}
	return 0;
}