/*
Module Four Assignment: Working With Files
Author: Suraj Hamal
Date: 02/06/2024
Class: CS-210 Programming
Purpose: Open a file, Store it into the lists, convert its contents from Farenheit to Celsious and write it in a new file.
 */


#include <iostream>
#include <fstream>
#include <stdlib.h>
#include <iomanip>
#include <string>
#include <vector>
using namespace std;


int main() {
	// initializing variables and vectors needed for the program
	ifstream inFS;		// declaring input file stream variable to read from the file
	ofstream outFS;		// declaring output file stream variable to write the file
	string fileWord;		// creating string varible to assign cities
	int fileNum;			// creating int variable to assign temperature
	vector<string> citiesVect;		// creating empty string list to store cities
	vector<int> tempsVect;			// creating empty int list to store temperature


	// opens the FahrenheitTemperature.txt file
	cout << "Opening file : FahrenheitTemperature.txt ..." << endl;
	cout << endl;
	inFS.open("FahrenheitTemperature.txt");
	if (!inFS.is_open()) {
		cout << "Error: Unable to open the file!" << endl;
		return 1;
	}

	// Loop to read and append the cities and temperature from the 
	// FahrenheitTemperature.txt file to city vector list and temp vector list
	cout << "Here are the temps from your current file:\n" << endl;
	inFS >> fileWord;
	inFS >> fileNum;
	while (!inFS.fail()) {
		citiesVect.push_back(fileWord);
		tempsVect.push_back(fileNum);

		inFS >> fileWord;
		inFS >> fileNum;

	}
	// Loop to print the contents of the file to the console
	for (int i = 0; i < citiesVect.size(); i++) {
		cout << citiesVect.at(i) << " " << tempsVect.at(i) << endl;
	}


	// Checks to see if the file is reached the end of line
	if (!inFS.eof()) {
		cout << "Error: Input failure before reaching the end of the file!" << endl;
	}
	cout << endl;
	cout << "Closing FahrenheitTemperature.txt ..." << endl;
	cout <<"------------------------------------------------" << endl;
	cout << endl;

	inFS.close(); // Closes FahrenheitTemperature.txt file

	// Creates and opens CelsiusTemperature.txtfile
	cout << "Opening file: CelsiusTemperature.txt ..." << endl;
	outFS.open("CelsiusTemperature.txt");

	// Checks to see if file is already opened
	if (!outFS.is_open()) {
		cout << "Error: Could not open the new file, 'CelsiusTemperature.txt'!" << endl;
		return 1;
	}

	cout << endl;
	cout << "Here's your new file with temps converted to Celsius:\n" << endl;

	// Iterates through the cities and temperature list to convert Farenheit to celsious as the type double,
	// before getting printed in a new file
	for (int i = 0; i < citiesVect.size(); i++) {
		cout << citiesVect.at(i) << " " << (tempsVect.at(i) - 32) * (5.0 / 9.0) << " \370C" << endl;	// Prints the converted list into the console
		outFS << citiesVect.at(i) << " " << (tempsVect.at(i) -32) * (5.0 / 9.0) << endl;				// Output stream to write the converted temperature with cities in CelsiusTemperature.txt file 
	}
	
	cout << endl;
	cout << "Closing CelsiusTemperature.txt ..." << endl;
	cout << "------------------------------------------------" << endl;

	outFS.close(); // Closes CelsiusTemperature.txt file

	return 0;
}